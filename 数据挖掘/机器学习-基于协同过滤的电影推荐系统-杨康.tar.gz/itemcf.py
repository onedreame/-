# coding:utf-8
import zipfile
import random, operator
import math
import tensorflow as tf
from matplotlib import pylab as plt
import sys, random, math


random.seed(0)


class UBCF():
    def __init__(self, n_rec):
        self.n_rec = n_rec
        self.u_sim_mat = {}
        self.trainsets = {}
        self.testsets = {}
        self.movie_popular = {}
        self.n_sim_usr = 0
        self.n_movier_rec = 10
        self.f1 = []
        self.precision = []
        self.recall = []
        self.coverage = []
        self.n_sim_movie = 0
        self.n_rec_movie = 0

        self.movie_sim_mat = {}
        self.movie_count = 0

    @staticmethod
    def load_data(filename):
        '''
        加载数据
        :param filename: 训练集文件名
        :return: 单条数据
        '''

        with open(filename, 'r+') as f:
            i = 0
            for line in f.readlines():
                yield line.strip('\r\n')

    def generate_datasets(self, filename, pivot=0.7):

        train_len = 0
        test_len = 0

        for line in self.load_data(filename):
            if train_len > 1000 and test_len > 500: break  # �ⲿ����ԭ����û��

            user, movie, rating, timestamp = line.split('::')
            if random.random() < pivot:
                self.trainsets.setdefault(user, {})
                self.trainsets[user][movie] = int(rating)
                train_len += 1
                self.movie_popular[movie] = self.movie_popular.get(movie, 0) + 1  # �ⲿ����ԭ����û��
            else:
                self.testsets.setdefault(user, {})
                self.testsets[user][movie] = int(rating)
                test_len += 1

    def cal_sim(self):

        print('构建用户相似度模型...\n')
        for user, movies in self.trainsets.items():  # ѵ�����ֵ��еļ�user��ֵmovies
            for movie in movies:
                # count item popularity
                if movie not in self.movie_popular:  # ĳ��Ӱ���ٸ���Ȥ�ĵ�Ӱ�ֵ��У�������������ֵ��еĴ˲���ӰΪ0�������һ��
                    self.movie_popular[movie] = 0
                self.movie_popular[movie] += 1
        # save the total number of movies
        self.movie_count = len(self.movie_popular)  # ����Ȥ��Ӱ�����еĵ�Ӱ����
        # count co-rated users between items
        itemsim_mat = self.movie_sim_mat

        for user, movies in self.trainsets.items():  #
            for m1 in movies:
                for m2 in movies:
                    if m1 == m2: continue
                    itemsim_mat.setdefault(m1, {})  # ��itemsim_mat�в���m1����û�������ó�dict
                    itemsim_mat[m1].setdefault(m2, 0)  # ��m1 dict�в���m2����û��������Ϊ0
                    itemsim_mat[m1][m2] += 1  # m2����ֵÿ�μ�һ

        # calculate similarity matrix
        simfactor_count = 0
        PRINT_STEP = 2000000

        for m1, related_movies in itemsim_mat.items():
            for m2, count in related_movies.items():
                itemsim_mat[m1][m2] = count / math.sqrt(
                    self.movie_popular[m1] * self.movie_popular[m2])  # ���ڼ������ƶȵĹ�ʽ
                simfactor_count += 1
        self.movie_sim_mat=itemsim_mat
    def recommend(self, user):
        K = self.n_sim_movie  # 20
        N = self.n_rec_movie  # 10
        rank = dict()
        print('recommend ,k = %d, n=%d.'%(K,N))
        watched_movies = self.trainsets[user]  # �ҳ����û������ĵ�Ӱ
        for movie, rating in watched_movies.items():
           # print('####print###########################')
            if movie in self.movie_sim_mat:
                #print(len(self.movie_sim_mat[movie]))
                #printnt('********************************')
                for related_movie, w in sorted(self.movie_sim_mat[movie].items(),
                                               key=operator.itemgetter(1), reverse=True)[:K]:
                    if related_movie in watched_movies:
                        continue
                    rank.setdefault(related_movie, 0)  # ��rank�в���related_movie��Ӱ����û������Ϊ0
                    rank[related_movie] += w * rating  # ���ƶȳ�������
        # return the N best movies
        return sorted(rank.items(), key=operator.itemgetter(1), reverse=True)[:N]  # ������һ�еĽ���������� ���ǰN��

    def evaluate(self):

        hits = 0
        tot_movie = 0
        tot_rec = 0
        all_rec_movie = set()
        popular_sum = 0

        print('开始分析推荐模型...')

        for i, user in enumerate(self.trainsets):
            if i % 500 == 0:
                print('recommend for %d users.\n' % i)
            test_movies = self.testsets.get(user, {})
            rec_movies = self.recommend(user)
            for movie, w in rec_movies:
                if movie in test_movies:
                    hits += 1
                all_rec_movie.add(movie)
                popular_sum += math.log(1 + self.movie_popular.get(movie, 0))
            tot_rec += self.n_movier_rec
            tot_movie += len(test_movies)

        with tf.name_scope('result'):
            popularity = popular_sum / (1.0 * tot_rec)
            self.precision[-1].append(hits / (1.0 * tot_rec))
            self.recall[-1].append(hits / (1.0 * tot_movie))
            self.coverage[-1].append(len(all_rec_movie) / (1.0 * self.movie_count))
            self.f1[-1].append(
                self.precision[-1][-1] * self.recall[-1][-1] / (self.precision[-1][-1] + self.recall[-1][-1] + 1e-5))
            print('precision is %f\n' % self.precision[-1][-1])
            print('recall is %f\n' % self.recall[-1][-1])
            print('coverage is %f.\n' % self.coverage[-1][-1])
            print('f1 is %f.' % self.f1[-1][-1])


cf = UBCF(5)
cf.generate_datasets('/home/yk/machine_learning/cf/practice/ratings.dat')
cf.cal_sim()  # �������ƶ�
num_person = []
num_rec = []
end_point = 10
start_point=5
import numpy as np
for k in range(start_point, end_point):
    num_rec.append([])
    cf.precision.append([])
    cf.coverage.append([])
    cf.recall.append([])
    cf.f1.append([])
    for n in range(2, end_point):
        print('从%d个人中推荐%d部电影.' %(k,n))
        num_rec[-1].append(n)
        cf.n_sim_movie = k
        cf.n_rec_movie = n
        cf.evaluate()
print('一共有%d条曲线.' %(len(num_rec)))
fig = plt.figure(1)
ax = plt.subplot(221)  # �������ֳ�2*2����ռ�õ�һ������
ax.set_xlabel('Number of Movies')
ax.set_ylabel('f1')
for i in range(len(num_rec)):
    plt.plot(num_rec[i], cf.f1[i])
    # plt.plot([4]*4,np.linspace(0,0.4,4))
    # print('绘制f1曲线：%d' %i)
    # print('num_rec: ',num_rec[i],',cf.f1: ',cf.f1[i])
    plt.annotate('n=%d' % (i + start_point), xy=(num_rec[i][-1], cf.f1[i][-1]), xytext=(min(i + 5, end_point - 2), cf.f1[i][-1]),
                 arrowprops=dict(facecolor='black', shrink=0.005, width=0.5, headwidth=1),
                 )
ax = plt.subplot(222)
ax.set_xlabel('Number of Movies')
ax.set_ylabel('precision')
for i in range(len(num_rec)):
    plt.plot(num_rec[i], cf.precision[i])
    plt.annotate('n=%d' % (i + start_point), xy=(num_rec[i][-1], cf.precision[i][-1]),
                 xytext=(min(i + 5, end_point - 2), cf.precision[i][-1]),
                 arrowprops=dict(facecolor='black', shrink=0.005, width=0.5, headwidth=1),
                 )
ax = plt.subplot(223)
ax.set_xlabel('Number of Movies')
ax.set_ylabel('recall')
for i in range(len(num_rec)):
    plt.plot(num_rec[i], cf.recall[i])
    plt.annotate('n=%d' % (i + start_point), xy=(num_rec[i][-1], cf.recall[i][-1]),
                 xytext=(min(i + 5, end_point - 2), cf.recall[i][-1]),
                 arrowprops=dict(facecolor='black', shrink=0.005, width=0.5, headwidth=1),
                 )
ax = plt.subplot(224)
ax.set_xlabel('Number of Movies')
ax.set_ylabel('coverage')
for i in range(len(num_rec)):
    plt.plot(num_rec[i], cf.coverage[i])
    print('num_rec is ',num_rec[i],',cf.coverage is ',cf.coverage[i])
    plt.annotate('n=%d' % (i + start_point), xy=(num_rec[i][-1], cf.coverage[i][-1]),
                 xytext=(min(i + 5, end_point - 2), cf.coverage[i][-1]),
                 arrowprops=dict(facecolor='black', shrink=0.005, width=0.5, headwidth=1),
                 )
plt.show()

