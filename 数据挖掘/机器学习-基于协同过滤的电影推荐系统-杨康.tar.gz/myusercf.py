#coding:utf-8
import zipfile
import random,operator
import math
import tensorflow as tf
from matplotlib import pylab as plt

random.seed(0)

class UBCF():


    def __init__(self,n_rec):
        self.n_rec=n_rec
        self.u_sim_mat={}
        self.trainsets={}
        self.testsets={}
        self.popular_movie={}
        self.movie2user={}
        # self.n_sim_usr=tf.placeholder(dtype=tf.int32)
        # self.n_movier_rec=tf.placeholder(dtype=tf.int32)
        self.n_sim_usr=0
        self.n_movier_rec=0
        self.f1=[]
        self.precision=[]
        self.recall=[]
        self.coverage=[]

    @staticmethod
    def load_data(filename):
        '''
        加载数据
        :param filename: 训练集文件名
        :return: 单条数据
        '''

        with open(filename,'r+') as f:
            i=0
            for line in f.readlines():
                yield line.strip('\r\n')


    def generate_datasets(self,filename,pivot=0.7):

        train_len=0
        test_len=0

        for line in self.load_data(filename):
            # if train_len>1000 and test_len>500: break

            user, movie, rating, timestamp=line.split('::')
            if random.random()<pivot:
                self.trainsets.setdefault(user,{})
                self.trainsets[user][movie]=int(rating)
                train_len+=1
                self.popular_movie[movie]=self.popular_movie.get(movie,0)+1
            else:
                self.testsets.setdefault(user,{})
                self.testsets[user][movie]=int(rating)
                test_len+=1

        for user,movies in self.trainsets.items():
            for movie in movies:
                self.movie2user.setdefault(movie,set())
                self.movie2user[movie].add(user)

        print('加载完数据集...\n')
        print('train_len is %d, test_len is %d.\n' %(train_len,test_len))
        self.movie_count=len(self.movie2user)
        print('movie_set is %d.\n' %self.movie_count)

    def cal_sim(self):

        print('构建用户相似度模型...\n')
        with tf.device('/gpu:0'):
            for movie,users in self.movie2user.items():
                for u in users:
                    for v in users:
                        if u==v: continue
                        self.u_sim_mat.setdefault(u,{})
                        self.u_sim_mat[u][v]=self.u_sim_mat[u].get(v,0)+1
            for user,users in self.u_sim_mat.items():
                for muser,count in users.items():
                    self.u_sim_mat[user][muser]=self.u_sim_mat[user][muser]/math.sqrt(len(self.trainsets[user])*len(self.trainsets[muser]))
                    # self.u_sim_mat[user][muser]=self.u_sim_mat[user][muser]/len(set(self.trainsets[user].keys())|set(self.trainsets[muser].keys()))
    def recommend(self,user):
        rank=dict()
        # print('self.n_sim_usr is %d,self.n_movie_rec is %d' %(self.n_sim_usr,self.n_movier_rec))
        #self.n_movier_rec=max(self.n_movier_rec,len(self.u_sim_mat[user]))
        watched_movies=self.trainsets[user]

        for u,wuk in sorted(self.u_sim_mat[user].items(),key=operator.itemgetter(1),reverse=True)[:self.n_sim_usr]:
            for movies in self.trainsets[u]:
                if movies in watched_movies:
                    continue
                rank[movies]=rank.get(movies,0)+wuk
        rec=sorted(rank.items(),key=operator.itemgetter(1),reverse=True)[:self.n_movier_rec]
        return rec

    def evaluate(self):

        hits=0
        tot_movie=0
        tot_rec=0
        all_rec_movie=set()
        popular_sum = 0

        print('开始分析推荐模型...')


        for i,user in enumerate(self.trainsets):
            if i%500==0:
                print('recommend for %d users.\n' %i)
            test_movies=self.testsets.get(user,{})
            rec_movies=self.recommend(user)
            for movie,w in rec_movies:
                if movie in test_movies:
                    hits+=1
                all_rec_movie.add(movie)
                popular_sum += math.log(1 + self.popular_movie.get(movie,0))
            tot_rec+=self.n_movier_rec
            tot_movie+=len(test_movies)

        with tf.name_scope('result'):
            # self.precision = tf.assign(self.precision,hits / (1.0*tot_rec))
            # self.recall = tf.assign(self.precision,hits / (1.0*tot_movie))
            # self.coverage = tf.assign(self.coverage,len(all_rec_movie) / (1.0*self.movie_count))
            popularity = popular_sum / (1.0*tot_rec)
            # tf.summary.scalar('precision',self.precision)
            # tf.summary.scalar('recall',self.recall)
            # tf.summary.scalar('coverge',self.coverage)
            self.precision[-1].append(hits / (1.0*tot_rec))
            self.recall[-1].append(hits / (1.0*tot_movie))
            self.coverage[-1].append(len(all_rec_movie) / (1.0*self.movie_count))
            self.f1[-1].append(self.precision[-1][-1]*self.recall[-1][-1]/(self.precision[-1][-1]+self.recall[-1][-1]+1e-5))
            print('precision is %f\n'% self.precision[-1][-1])
            print('recall is %f\n' %self.recall[-1][-1])
            print('coverage is %f.\n'%self.coverage[-1][-1])
            print('f1 is %f.' %self.f1[-1][-1])



cf=UBCF(5)
# writer=tf.summary.FileWriter('/tmp/to/log',tf.get_default_graph())
cf.generate_datasets('/home/yk/machine_learning/cf/practice/ratings.dat')
cf.cal_sim()
# merged=tf.summary.merge_all()
# with tf.Session() as sess:
num_person=[]
num_rec=[]
end_point=15
start_point=1
for k in range(start_point,end_point):
    num_rec.append([])
    cf.precision.append([]);cf.coverage.append([])
    cf.recall.append([]);
    cf.f1.append([])
    for n in range(5,end_point):
        print('从%d个人中推荐%d部电影.' %(k,n))
        num_rec[-1].append(n)
        cf.n_sim_usr=k;cf.n_movier_rec=n
        cf.evaluate()
        # cf.evaluate()
        # summary,
        # precison,recall,coverage=sess.run([cf.precision,cf.recall,cf.coverage])
        # print('precision is %f\n'% precison)
        # print('recall is %f\n' %recall)
        # print('coverage is %f.\n'%coverage)
        # writer.add_summary(summary)
fig=plt.figure(1)
# plt.rcParams['font.sans-serif']=['SimHei']
# plt.rcParams['axes.unicode_minus'] = False
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
ax=plt.subplot(221)
ax.set_xlabel('Number of Movies')
ax.set_ylabel('f1')
for i in range(len(num_rec)):
    plt.plot(num_rec[i],cf.f1[i])
    # plt.text(i,cf.f1[i][0],'candidates= %d' %(i+5))
    plt.annotate('n=%d' %(i+start_point), xy=(num_rec[i][-1], cf.f1[i][-1]), xytext=(min(i+5,end_point-2), cf.f1[i][-1]),
                 arrowprops=dict(facecolor='black', shrink=0.005,width=0.5,headwidth=1),
                 )
ax=plt.subplot(222)
ax.set_xlabel('Number of Movies');ax.set_ylabel('precision')
for i in range(len(num_rec)):
    plt.plot(num_rec[i],cf.precision[i])
    plt.annotate('n=%d' %(i+start_point), xy=(num_rec[i][-1], cf.precision[i][-1]), xytext=(min(i+5,end_point-2), cf.precision[i][-1]),
                 arrowprops=dict(facecolor='black', shrink=0.005,width=0.5,headwidth=1),
                 )
ax=plt.subplot(223)
ax.set_xlabel('Number of Movies');ax.set_ylabel('recall')
for i in range(len(num_rec)):
    plt.plot(num_rec[i],cf.recall[i])
    plt.annotate('n=%d' %(i+start_point), xy=(num_rec[i][-1], cf.recall[i][-1]), xytext=(min(i+5,end_point-2), cf.recall[i][-1]),
                 arrowprops=dict(facecolor='black', shrink=0.005,width=0.5,headwidth=1),
                 )
ax=plt.subplot(224)
ax.set_xlabel('Number of Movies');ax.set_ylabel('coverage')
for i in range(len(num_rec)):
    plt.plot(num_rec[i],cf.coverage[i])
    plt.annotate('n=%d' %(i+start_point), xy=(num_rec[i][-1], cf.coverage[i][-1]), xytext=(min(i+5,end_point-2), cf.coverage[i][-1]),
                 arrowprops=dict(facecolor='black', shrink=0.005,width=0.5,headwidth=1),
                 )
# ax = Axes3D(fig)
# num_person,num_rec=np.meshgrid(num_person,num_rec)
# ax.plot_surface(num_person, num_rec, cf.f1, rstride=1, cstride=1, cmap='rainbow')
# ax.set_zlabel('f1') #坐标轴
# ax.set_ylabel('Number of Movies')
# ax.set_xlabel('Number of Candidates')
plt.show()

